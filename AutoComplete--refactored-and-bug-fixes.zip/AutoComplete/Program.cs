﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AutoComplete
{
	class Program
	{
		private static Dictionary<int, string> wordsfreqDict;
		private static Dictionary<int, string> partialMatch;
		private static Dictionary<int, string> sortedPartialMatch;
		private static Dictionary<int, string> listofKwords;
		static void Main(string[] args)
		{
			//Here is my approach
			//Step1: Load the words.txt into dictionary
			//Step2: Read the input file from CLI and parse the file
			//Step3: for each line in input file sample_input.txt loop through below
			//Step4: retrieve subdictionary with the partial matches with the file like like M* from dictionary values.
			//Step5: Sorty subdictionary on Keys (frequencies)
			//Step6: Write top K Words from subdictionary into a file.
			//Step7: repeast Step3 - Step6 for each work in input file.

			string pathToWordsFile = args[0];
			string pathToInputFile = args[1];
			int k = Int32.Parse(args[2]);
			string pathToOutputFile = args[3];

			if (!File.Exists(pathToWordsFile) || !File.Exists(pathToInputFile) || !File.Exists(pathToOutputFile) || k <= 0)
				return;

			//Step1. 
			wordsfreqDict = LoadFileToDict(pathToWordsFile);
			File.WriteAllText(pathToOutputFile, string.Empty);

			var lines = File.ReadLines(pathToInputFile);
			foreach (var line in lines)
			{
				//Step2, 3
				partialMatch = PartialMatch(pathToInputFile, line);

				//Step4, 5
				sortedPartialMatch = sortPartialMatchOnFrequency(partialMatch);

				//Step6
				listofKwords = ListTopKWords(sortedPartialMatch, k);
				
				WriteToOutPutFile(pathToOutputFile, line);
			}
		}

		static Dictionary<int, string> LoadFileToDict(string path)
		{
			Dictionary<int, string> wordsfreqDict = new Dictionary<int, string>();
			var lines = File.ReadLines(path);
			foreach (var line in lines)
			{
				var temp = line.Split('\t');
				if (!wordsfreqDict.ContainsKey((Int32.Parse(temp[0].Trim()))))
				{
					wordsfreqDict.Add(Int32.Parse(temp[0].Trim()), temp[1]);
				}
			}

			return wordsfreqDict;
		}

		static Dictionary<int, string> PartialMatch(string pathtoInput, string line)
		{
			Dictionary<int, string> partialMatch1 = new Dictionary<int, string>();
			foreach (KeyValuePair<int, string> kvp in wordsfreqDict)
			{
				if (kvp.Value.Substring(0, line.Length) == line)
				{
						partialMatch1.Add(kvp.Key, kvp.Value);
				}
			}
			return partialMatch1;
		}

		static Dictionary<int, string> sortPartialMatchOnFrequency(Dictionary<int, string> partialMatch)
		{
			Dictionary<int, string> sortedPartialMatchOnFreq = new Dictionary<int, string>();
			var list = partialMatch.Keys.ToList();
			list.Sort();
			var sortedKeys = from key in partialMatch.Keys
									orderby key descending
									select key;
			foreach (var key in sortedKeys)
			{
				sortedPartialMatchOnFreq.Add(key, partialMatch[key]);
			}
			return sortedPartialMatchOnFreq;
		}

		static Dictionary<int, string> ListTopKWords(Dictionary<int, string> sortedPartialMatch, int k)
		{
			Dictionary<int, string> listofKwords = new Dictionary<int, string>();
			int kCounter = 0;
			foreach (KeyValuePair<int, string> kvp in sortedPartialMatch)
			{
				listofKwords.Add(kvp.Key, kvp.Value);
				kCounter += 1;
				if (kCounter == k)
				{
					break;
				}
			}
			return listofKwords;
		}
		static void WriteToOutPutFile(string path, string inputline)
		{
			using (StreamWriter writetext = new StreamWriter(path, true))
			{
				writetext.WriteLine("{0}:",inputline);
				foreach (KeyValuePair<int, string> kvp in listofKwords)
				{
					string line = string.Format("{0}, ({1})", kvp.Value, kvp.Key.ToString());
					writetext.WriteLine(line);
				}
				writetext.WriteLine();
			}
		}
	}
}
