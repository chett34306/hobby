﻿1. Open the .csproj file in Visual Studio(VS) Enterprise 2017 (older version might work). This should open all the project files.
2. Use the menu "Build" or right click to compile the project. 
3. Hit F5 to run the program from VS or launch autocomplete.exe with params from CLI.
4. Full implementation will be in program.cs file.