{
	"en": {
		"WELCOME_MESSAGE": "Welcome to Urban Living.",
		"WHAT_CAN_SKILL_DO": "Here you can learn about what Urban Living is about. You can also subcribe by saying subscribe",
		"SKILL_NAME": "Urban Living",
		"GET_FACT_MESSAGE": "Here's your daily journal: {}",
		"WHATS_NEXT" : "Whats next, you can say, may tenth article or may fifth two thousand article",
		"HELP_MESSAGE": "You can say read daily journal or daily journal or open daily journal, or, you can say exit... What can I help you with?",
		"HELP_REPROMPT": "What can I help you with?",
		"FALLBACK_MESSAGE": "The daily journal skill can't help you with that.  It can help you discover articles by Trish and Rhea in daily writing. What can I help you with?",
		"FALLBACK_REPROMPT": "What can I help you with?",
		"ERROR_MESSAGE": "Sorry, an error occurred.",
		"STOP_MESSAGE": "Goodbye!"
		}
}